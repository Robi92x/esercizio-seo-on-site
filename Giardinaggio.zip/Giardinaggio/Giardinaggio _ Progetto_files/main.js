jQuery(document).ready(function ($) {
    "use strict";

	//Initialize for inline images
	$('.pop').magnificPopup({type:'image'});
	//Initialize for wordpress galleries
	$('.gallery, .woocommerce-product-gallery').magnificPopup({
		delegate: 'a',
		type: 'image',
		zoom: {
			enabled: !0,
			duration: 300
		},
		gallery: {
			enabled: true
		},
	});

	//
	$(document).on('click', '.mkd-quantity-minus, .mkd-quantity-plus', function (e) {
		e.stopPropagation();

		var button = $(this),
			inputField = button.siblings('.mkd-quantity-input'),
			step = parseFloat(inputField.attr('step')),
			max = parseFloat(inputField.attr('max')),
			minus = false,
			inputValue = parseFloat(inputField.val()),
			newInputValue;

		if (button.hasClass('mkd-quantity-minus')) {
			minus = true;
		}

		if (minus) {
			newInputValue = inputValue - step;
			if (newInputValue >= 1) {
				inputField.val(newInputValue);
			} else {
				inputField.val(1);
			}
		} else {
			newInputValue = inputValue + step;
			if (max === undefined) {
				inputField.val(newInputValue);
			} else {
				if (newInputValue >= max) {
					inputField.val(max);
				} else {
					inputField.val(newInputValue);
				}
			}
		}
		inputField.trigger('change');
	});

	//Widget tabs
	$(".widget-tabs .widget-tab-titles li").click(function() {
		$(this).siblings("li").removeClass('active');
		$(this).addClass("active");
		$(this).parents(".widget-tabs").find(".tab-content").hide();
		var selected_tab = $(this).find("a").attr("href");
		$(this).parents(".widget-tabs").find(selected_tab).show();
		return false;
	});

	//Lazy-load
	$("img.lazy").lazyload({ effect : "fadeIn" });

	//Fixed-header
	var navwrapper = $(".main-navigation-content");
	var stickynav = $(".sticky-navigation");
	navwrapper.clone().appendTo(stickynav);
	navwrapper.each(function(){
		var window_scrolltop;

		$(window).scroll(function(){
			window_scrolltop = $(this).scrollTop();
			if(window_scrolltop > 260){
				stickynav.addClass("fixed-header" ,1000);
			}
			else {
				stickynav.removeClass("fixed-header" ,1000);
			}
		});
	});

	// Socials block
	$(".socials-box").hover(function(){
		$(this).addClass("socials-box-open");
		}, function(){
		$(this).removeClass("socials-box-open");
	});

	// Sticky sidebar
	var sidebarstick = $(".sidebar-stick");
	if ($(window).width() > 960) {
	   sidebarstick.each(function(){
			sidebarstick.theiaStickySidebar({
				additionalMarginTop: 90,
				additionalMarginBottom: 40,
			});
		});
	};

	// Back to top
	var backtotop = $(".back-to-top");
	backtotop.each(function(){
		var offset = 620;
		var duration = 500;
			$(window).scroll(function() {
				if ($(this).scrollTop() > offset) {
					backtotop.fadeIn(duration);
					backtotop.addClass("fadetotop");
				} else {
					backtotop.fadeOut(duration);
					backtotop.removeClass("fadetotop");
				}
		});

		backtotop.on("click", function(event) {

			event.preventDefault();
			$('html, body').animate({scrollTop: 0}, 1000);

		return false;
		});
	});

    // Sliders setting up
    $(".carousel-default").owlCarousel({loop:!0,items:1,autoplay:!0,autoplayTimeout:7000,autoplaySpeed:2500,navSpeed:2500,nav:true,navText:!1,dots:!0,responsive:{1199:{items:1},0:{items:1}}});

	$(".carousel-two").owlCarousel({loop:!0,items:2,autoplay:!0,autoplayTimeout:3500,autoplaySpeed:2000,navSpeed:2000,margin:20,nav:true,navText:!1,dots:!0,responsive:{979:{items:2},0:{items:1}}});

	$(".carousel-full-three").owlCarousel({loop:!0,items:3,autoplay:!0,autoplayTimeout:3500,autoplaySpeed:2000,navSpeed:2000,margin:20,nav:true,navText:!1,dots:!1,responsive:{979:{items:3},0:{items:1}}});

	$(".carousel-onef").owlCarousel({loop:!0,items:1,autoplay:!0,autoplayTimeout:3500,autoplaySpeed:2000,navSpeed:2000,nav:true,navText:!1,dots:!1,responsive:{1199:{items:1},0:{items:1}}});

	$(".carousel-twof").owlCarousel({loop:!0,items:2,autoplay:!0,autoplayTimeout:3500,autoplaySpeed:2000,navSpeed:2000,margin:20,nav:true,navText:!1,dots:!1,responsive:{979:{items:2},0:{items:1}}});

	$(".carousel-fourit").owlCarousel({loop:!0,items:3,autoplay:!0,autoplayTimeout:3500,autoplaySpeed:2000,navSpeed:2000,nav:true,margin:30,navText:!1,dots:!0,responsive:{979:{items:3},0:{items:1}}});

	$(".carousel-mostlike").owlCarousel({items:4,autoplay:!0,autoplayTimeout:3500,autoplaySpeed:2000,navSpeed:2000,nav:true,margin:20,navText:!0,dots:0,responsive:{979:{items:4},480:{items:2},0:{items:1}}});

	// Post slider
	$('.bxslider').bxSlider({
	  adaptiveHeight: true,
	  mode: 'fade',
	  pager: false,
	  captions: true
	});

	// Searchbox
	var submitIcon = $('.searchbox-icon');
    var searchWrapper = $('.search-wrapper');
	var searchClose = $('.search-wrapper-close');
	var searchForm = $('.search-form');

    submitIcon.click(function(){
		searchWrapper.addClass('wrapper-active');
		searchForm.css('display', 'block');
		socIcons.css('display', 'none');
    });
	searchClose.click(function(){
         searchWrapper.removeClass('wrapper-active');
    });

	// Header Socials
	var socIcon = $('.header-soc-icon');
	var socWrapper = $('.search-wrapper');
	var socClose = $('.search-wrapper-close');
	var socIcons = $('.header-socials-block');

	socIcon.click(function(){
		socWrapper.addClass('wrapper-active');
		searchForm.css('display', 'none');
		socIcons.css('display', 'block');
	});
	socClose.click(function(){
		socWrapper.removeClass('wrapper-active');
	});

    // toggle sidebar
    $('.sidebar-scroll').each(function(){
        $("body").on("click",".menu-icon", function(e){
            $("html").addClass("glide-nav-open");
            e.stopPropagation();
            e.preventDefault();
        });

        $("body").on("click",".close-btn", function(e){
            $("html").removeClass("glide-nav-open");
            $("html").removeClass("overflow-clear");
            e.preventDefault();
        });

		$(".sidebar-scroll ul li.menu-item-has-children").append( "<i class='fa fa-angle-down'></i>" );
        $(".sidebar-scroll ul li.menu-item-has-children i").on("click", function() {
            var link = $(this);
            var closest_ul = link.closest("ul");
            var parallel_active_links = closest_ul.find(".active")
            var closest_li = link.closest("li");
            var link_status = closest_li.hasClass("active");
            var count = 0;
            closest_ul.find("ul").slideUp(function() {
                if (++count == closest_ul.find("ul").length)
                        parallel_active_links.removeClass("active");
            });
            if (!link_status) {
                closest_li.children("ul").slideDown();
                closest_li.addClass("active");
            }
        });
        $('.scrollbar-macosx').scrollbar();
    });
	$(".background-block, .background-opacity").width($(window).width());

	// Fitvids
	$(".container").fitVids();
});